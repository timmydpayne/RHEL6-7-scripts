#!/bin/bash

DOWNLOAD_DIR="/repo"
CACHE_DIR="/tmp/repocreate"

CHECK_PREREQS()
{
	if [ `which reposync &> /dev/null; echo ${?}` -ne "0" ]
	then
		echo "[WARNING] reposync utility is not installed"
		echo "[INFO] Installing yum-utils"

		yum install yum-utils -y &> /dev/null

		if [ ${?} -eq "0" ]
		then
			echo "[INFO] Succesfully installed reposync utility"
		else
			echo "[ERROR] Failed to install reposync utility"
			exit
		fi
	fi

	if [ `grep ${DOWNLOAD_DIR} /proc/mounts >> /dev/null ; echo ${?}` -ne "0" ]
	then
		echo "[WARNING] Repository directory {${DOWNLOAD_DIR}) is not mounted"
		echo "[INFO] Mounting repository directory"

		mount -t vboxsf repo ${DOWNLOAD_DIR} &> /dev/null

		if [ ${?} -eq "0" ]
		then
			echo "[INFO] Successfully mounted repository directory (${DOWNLOAD_DIR})"
		else
			echo "[ERROR] Failed to mount repository directory (${DOWNLOAD_DIR})"
			exit
		fi
	fi
}

SYNC_REPOS()
{
	RUN_STATUS=`ps -ef | grep /usr/bin/reposync | grep -v grep  &> /dev/null; echo ${?}`

	if [ ! -d ${DOWNLOAD_DIR} ]
	then
		echo "[ERROR] Repository directory (${DOWNLOAD_DIR}) is missing"
		exit
	else
		echo "[INFO] Cleaning repository metadata"
#		find ${DOWNLOAD_DIR} -type f ! -name "*.rpm" -delete
	fi

	if [ ${RUN_STATUS} -eq "0" ]
	then
		echo "[WARNING] reposync is currently running -- aborting"
		exit
	else
		echo "[INFO] Running reposync"
		reposync --plugins --download_path=${DOWNLOAD_DIR} --download-metadata --delete
	fi
}

CREATE_REPOS()
{
	for REPO_DIR in `ls -d ${DOWNLOAD_DIR}/*/`	 
	do
		REPO_NAME=`echo ${REPO_DIR} | awk  -F / '{print $(NF-1)}'`
	
		echo -e
		echo "[${REPO_NAME}]"
		echo -e

		GROUPINFO_FILE=`ls -t ${REPO_DIR}/*-comps*.bz2 2> /dev/null | head -1`

		if [[ -f ${GROUPINFO_FILE} && $? -eq 0 ]]
		then
			echo "Extracting comps.xml (bz2)"
			bzip2 -dc ${GROUPINFO_FILE} > ${REPO_DIR}/comps.xml
		fi

		GROUPINFO_FILE=`ls -t ${REPO_DIR}/*-comps*.gz 2> /dev/null | head -1`

		if [[ -f ${GROUPINFO_FILE} && $? -eq 0 ]]
		then
			echo "Extracting comps.xml (gz)"
			zcat ${GROUPINFO_FILE} > ${REPO_DIR}/comps.xml
		fi

		UPDATEINFO_FILE=`ls -t ${REPO_DIR}/*-updateinfo*.bz2 2> /dev/null | head -1`

		if [[ -f ${UPDATEINFO_FILE} && $? -eq 0 ]]
		then
			echo "Extracting updateinfo.xml (bz2)"
			bzip2 -dc ${UPDATEINFO_FILE} > ${REPO_DIR}/updateinfo.xml
		fi

		UPDATEINFO_FILE=`ls -t ${REPO_DIR}/*-updateinfo*.gz 2> /dev/null | head -1`

		if [[ -f ${UPDATEINFO_FILE} && $? -eq 0 ]]
		then
			echo "Extracting updateinfo.xml (gz)"
			zcat ${UPDATEINFO_FILE} > ${REPO_DIR}/updateinfo.xml
		fi

		if [ -f ${REPO_DIR}/comps.xml ]
		then
			echo "Creating repository with group information"
			createrepo ${REPO_DIR} --cachedir ${CACHE_DIR} --groupfile comps.xml --workers 4 --update &> /dev/null
		else
			echo "No group information available"
			createrepo ${REPO_DIR} --cachedir ${CACHE_DIR} --workers 4 --update &> /dev/null
		fi

		if [ -f ${REPO_DIR}/updateinfo.xml ]
		then
			echo "Modifying repository with update information"
			modifyrepo ${REPO_DIR}/updateinfo.xml ${REPO_DIR}/repodata/ &> /dev/null
		else
			echo "No update information available"
		fi
	done
}

CHECK_PREREQS
SYNC_REPOS
#CREATE_REPOS
