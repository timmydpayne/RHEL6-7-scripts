#!/bin/bash

PKG_INSTALL_LIST="./01-install-rhel-packages.conf"

for PKG in `cat ${PKG_INSTALL_LIST}` 
do
	if [ `rpm -qi ${PKG} --quiet; echo ${?}` != 0 ]
	then
		
		echo "[INFO] Installing ${PKG}"

		#yum install -y ${PKG} &> /dev/null
		yum install -y ${PKG}
		
		if [ ${?} -eq "0" ]
		then
			echo "[INFO] Successfully installed ${PKG}"
		else
			echo "[ERROR] Failed to install ${PKG}"
			exit
		fi
	fi
done
