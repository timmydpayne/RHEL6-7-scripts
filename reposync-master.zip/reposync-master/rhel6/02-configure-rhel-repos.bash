#!/bin/bash

PROXY=http://lackland.proxy.us.af.mil:8080

REPO_ENABLE_FILE="./02-configure-rhel-repos.conf"

REGISTER_SYSTEM()
{
	subscription-manager register --force --auto-attach --proxy=${PROXY}

	if [ ${?} != 0 ]
	then
		echo "[ERROR] Registration failed"
		exit
	fi
}

CONFIGURE_REPOS()
{
	echo "Disabling previously registered repositories"
	subscription-manager repos --disable=* --proxy=${PROXY}
	echo -e

	for REPO in `cat ${REPO_ENABLE_FILE}` 
	do
		echo "Enabling ${REPO}"
		subscription-manager repos --enable=${REPO} --proxy=${PROXY}
		echo -e
	done
}

REGISTER_SYSTEM
CONFIGURE_REPOS
