#!/bin/bash

REPO_DIR="/repo"
EXPORT_DIR="/export"

if [ `grep ${REPO_DIR} /proc/mounts >> /dev/null ; echo ${?}` -ne "0" ]
then
	echo "[WARNING] Repository directory {${REPO_DIR}) is not mounted"
	echo "[INFO] Mounting repository directory"

	mount -t vboxsf repo ${REPO_DIR} &> /dev/null

	if [ ${?} -eq "0" ]
	then
		echo "[INFO] Successfully mounted repository directory (${REPO_DIR})"
	else
		echo "[ERROR] Failed to mount repository directory (${REPO_DIR})"
		exit
	fi
fi

if [ `grep ${EXPORT_DIR} /proc/mounts >> /dev/null ; echo ${?}` -ne "0" ]
then
	echo "[WARNING] Export directory {${EXPORT_DIR}) is not mounted"
	echo "[INFO] Mounting export directory"

	mount -t vboxsf export ${EXPORT_DIR} &> /dev/null

	if [ ${?} -eq "0" ]
	then
		echo "[INFO] Successfully mounted export directory (${EXPORT_DIR})"
	else
		echo "[ERROR] Failed to mount export directory (${EXPORT_DIR})"
		exit
	fi
fi

for REPO in `ls ${REPO_DIR}`
do
	echo "[INFO] Exporting repository: ${REPO}"
	cd ${REPO_DIR}
	tar -czf ${EXPORT_DIR}/${REPO}.tar.gz ${REPO}
done
